# Duelo dos Dragões — desenvolvimento passo a passo

Este é um protótipo de luta 2D medieval para um jogador contra o computador. A tecnologia escolhida foi JavaScript com Canvas, para começar sem instalar uma engine. O objetivo desta primeira versão é validar se movimentar, atacar e defender forma um combate divertido. Ainda não é um jogo comercial finalizado.

## 1. Execute o projeto

Mantenha todos os arquivos na mesma pasta e abra `index.html` no navegador. Clique em **Começar duelo**. Não é necessário instalar pacotes ou conectar à internet. Se recebeu o ZIP, extraia primeiro.

Você controla Ignis, o dragão vermelho, contra Azur, o azul. A/D movem, W salta, J usa garras, K lança fogo, L defende, P pausa e R reinicia. Também existem botões de toque. Reduza a vida do adversário a zero para vencer.

## 2. Defina as regras antes de ampliar o jogo

Os dois dragões começam com 100 de vida e 100 de energia. Garras causam 12 de dano e exigem proximidade, com intervalo de 0,6 segundo. Fogo causa 17 de dano, custa 28 de energia e tem intervalo de 0,85 segundo. Energia se recupera em 19 pontos por segundo quando o dragão não está defendendo.

A defesa funciona contra ataques vindos da frente: reduz o dano em 80%, gasta 8 de energia por impacto e consome 13 por segundo enquanto mantida. Saltar ajuda a evitar projéteis. Essa combinação oferece decisões de alcance e uso de recursos.

Critério de conclusão desta etapa: ambos podem causar dano e existe uma vitória, derrota ou empate.

## 3. Organize responsabilidades

- `index.html`: estrutura da tela, estilos e instruções.
- `engine.js`: estado dos dragões, movimento, gravidade, colisões, dano, energia e decisões do computador.
- `game.js`: teclado, toque, pausa, desenho e ciclo de atualização.
- `arena.png` e `dragon.png`: arte do cenário e do personagem.

O motor recebe intenções como `move`, `jump`, `claw`, `fire` e `block`. Ele não precisa saber se vieram de uma tecla, botão de toque ou inteligência artificial. Assim, um modo de dois jogadores pode usar as mesmas regras no futuro.

## 4. Implemente movimento e salto

Cada personagem possui posição horizontal e vertical, velocidade vertical e direção. A velocidade é multiplicada pelo tempo transcorrido para manter consistência. A gravidade aumenta a velocidade vertical e o chão interrompe a queda. Limites laterais mantêm os dragões na arena.

O desenho utiliza `requestAnimationFrame`. A simulação avança em passos fixos de 1/60 de segundo, com limite de tempo acumulado após travamentos. Separar simulação e desenho ajuda a manter o combate estável em telas com frequências diferentes.

Critério de conclusão: mover para ambos os lados, saltar e aterrissar sem atravessar o chão.

## 5. Acrescente ataques e colisões

Garras verificam distância horizontal e vertical no instante do ataque. Fogo cria um projétil com posição, velocidade, proprietário e tempo de vida. A cada passo, o motor verifica se ele atingiu o adversário e remove projéteis que acertaram ou saíram da arena.

Os intervalos entre ataques impedem dano a cada quadro. Nesta versão as áreas de acerto são aproximações simples, independentes da ilustração. Uma versão mais refinada usaria áreas ajustadas por quadro de animação.

Critério de conclusão: garras não atingem de longe, fogo não atinge quem disparou e cada projétil causa dano uma única vez.

## 6. Adicione defesa e energia

A função `hit` concentra o cálculo do dano. Ela verifica direção e energia para decidir se a defesa é válida. Vida e energia têm limites, evitando números negativos. As barras mostram os valores atuais.

Experimento: altere o custo de fogo de 28 para 40 dentro de `act` e observe como o jogador precisa esperar mais entre sequências. Altere custo e verificação juntos. Em uma próxima refatoração, esses números devem ficar em um único objeto de configuração.

## 7. Programe o adversário

O computador se aproxima quando está longe, usa garras de perto, lança fogo à distância e tenta saltar quando um projétil se aproxima. Defende durante intervalos previsíveis. É uma inteligência artificial baseada em regras, sem aprendizado de máquina.

Isso permite começar com comportamento compreensível. Para melhorar depois, acrescente tempo de reação e estados de aproximação, ataque, defesa e recuperação. Os ataques atuais não têm antecipação animada; acrescentá-la é uma prioridade para tornar o combate mais legível.

## 8. Cuide do ciclo completo da partida

A interface possui estados de início, jogo, pausa e resultado. Perder o foco da janela pausa a partida e limpa os controles. Reiniciar cria um novo estado, removendo vida perdida e projéteis anteriores. O resultado também aparece como texto acessível fora do Canvas.

## 9. Teste antes de adicionar recursos

Foram preparados testes automatizados das regras: alcance das garras, consumo de energia, proteção frontal, dano traseiro, colisão de projéteis, limites de posição e resultado da partida.

Faça também estes testes manuais no seu navegador: complete uma vitória e uma derrota; pause durante um salto; mantenha defesa até a energia acabar; teste os botões de toque; reinicie após receber dano. Os testes de regras não substituem essa avaliação de jogabilidade.

## 10. Evolua em pequenas entregas

Ordem sugerida: primeiro ajustar alcance, dano e ritmo com partidas reais; depois adicionar animações de preparação, ataque e recuperação; então efeitos sonoros de golpes e melhorias na instrumentação; por fim modo local para dois jogadores, outras arenas e menus.

A versão atual usa oito quadros por dragão, incluindo quatro poses de caminhada e poses de salto, ataque, defesa e dano. `animation.js` escolhe a pose conforme o estado do combate; respiração, avanço no ataque e queda usam transformações interpoladas. A morte recua o corpo, passa para uma pose recolhida, comprime o corpo no chão e solta poeira. O resultado aguarda 1,8 segundo para não esconder a queda. É uma animação simples por poses e transformações, não uma animação esquelética.

As barras têm moldura dourada, gradientes luminosos, números e uma faixa clara que diminui depois do dano. O dragão azul usa uma folha própria em `dragon-blue-sprites.png`. A arte gerada preservou um fundo quadriculado: o renderizador remove os tons neutros claros em memória. O asset do dragão azul fica na pasta do projeto, sem link de download na interface do jogador. As imagens também ficam embutidas nos arquivos de dados JavaScript para permitir o processamento mesmo ao abrir o jogo diretamente em `file://`.

Os recortes não seguem uma grade perfeita: consulte `DragonAnimation.frames` em `animation.js`, cujos valores são `[x, y, largura, altura]` na folha de 1536 × 1024. A ordem é caminhada 1–4, salto, ataque, defesa e dano. O resultado do recorte foi conferido no jogo; a remoção por cor pode deixar pequenas imperfeições nas bordas. Não há multiplayer online, salvamento ou suporte a controle.

Validação nesta atualização: os 10 testes das regras passaram, assim como os testes de seleção de poses, ciclo de caminhada, limites dos recortes e progressão da morte sem dano após o resultado. A sintaxe JavaScript foi verificada. No navegador local foram conferidos o carregamento, as barras, os sprites sem fundo aparente, ataque de fogo, pausa, reinício e derrota. Isso não substitui testes extensivos de equilíbrio nem em dispositivos móveis.

Arte gerada com a ferramenta integrada de imagens. Prompts: folha com oito poses de um dragão medieval vermelho de perfil, seguida de extração do fundo; edição da mesma folha trocando escamas e asas vermelhas por azul safira/ciano, preservando detalhes dourados, dimensões e poses. Os arquivos PNG originais estão incluídos no projeto.

O scaffold de publicação encontrou um problema de acesso nesta sessão. Por isso esta entrega é local, sem endereço publicado. Os arquivos não dependem desse serviço para funcionar.

## 11. Trilha sonora

A trilha original em audio.js usa Web Audio: melodia de flauta sintetizada, arpejos de cordas, bordão e tambor. O ciclo tem 128 passos a 88 BPM. Ela inicia ao começar o duelo, para na pausa e no resultado e reinicia com uma nova partida. O botão Música permite silenciar; o volume começa em 25%. Funciona sem arquivos externos ou internet. São timbres sintetizados, não instrumentos gravados.

A implementação agenda pequenas porções da música pelo relógio do áudio para reduzir irregularidade entre quadros. Pausar cancela as notas, e uma identificação de execução impede retomadas antigas de criarem trilhas duplicadas. Testes automatizados cobrem agendamento, mute, limites de volume e cancelamento. Os controles foram conferidos no navegador; a qualidade sonora não foi avaliada por escuta nesta sessão.
